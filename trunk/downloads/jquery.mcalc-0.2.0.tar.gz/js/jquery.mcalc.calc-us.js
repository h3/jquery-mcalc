// Calculate monthly payments (United States formula)

$.ui.mcalc.defaults.calc = function() { 
    var d = this.data;
    if (d.cashdownType == 'raw') {
        var p = d.principal - d.cashdown;
    }
    else {
        var p = d.principal - (d.principal * d.cashdown/100);
    }

    d.yearlySubtotal = parseFloat(
        (p 
            * Math.pow(1 + d.yearlyInterest, d.yearlyPeriods) 
            * d.yearlyInterest
        ) 
        / (Math.pow(1 + d.yearlyInterest, d.yearlyPeriods) -1)
    , 10)

    d.yearlyTotal = parseFloat(
        d.yearlySubtotal 
        + (d.yearlyPropretyTax * p) 
        + d.yearlyInsurance 
        + (d.pmi * 12)
    , 10)

    d.monthlySubtotal = parseFloat(
        (p 
            * Math.pow(1 + d.monthlyInterest, d.monthlyPeriods) 
            * d.monthlyInterest
        ) 
        / (Math.pow(1 + d.monthlyInterest, d.monthlyPeriods) -1)
    , 10)

    d.monthlyTotal = parseFloat(
        d.monthlySubtotal 
        + (d.monthlyPropertyTax * p) / 12
        + d.monthlyInsurance + d.pmi
    , 10)

    var totals = (d.amortschedule == 'yearly')
        ? [d.yearlyTotal,  d.yearlySubtotal]
        : [d.monthlyTotal, d.monthlySubtotal]

    this._updateTotals.apply(this, totals);

};

